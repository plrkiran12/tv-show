import { createStore } from 'vuex';
import axios from 'axios';

export default createStore({
  state: {
    shows: [],
    searchQuery: '',
  },
  mutations: {
    SET_SHOWS(state, shows) {
      state.shows = shows;
    },
    SET_SEARCH_QUERY(state, query) {
      state.searchQuery = query;
    },
  },
  actions: {
    async fetchShows({ commit }) {
      try {
        const response = await axios.get('https://api.tvmaze.com/shows');
        commit('SET_SHOWS', response.data);
      } catch (error) {
        console.error('Error fetching shows:', error);
      }
    },
  },
  getters: {
    filteredShows: (state) => {
      return state.shows.filter(show =>
        show.name.toLowerCase().includes(state.searchQuery.toLowerCase())
      );
    },
    showsByGenre: (state, getters) => (genre) => {
      return getters.filteredShows.filter(show => show.genres.includes(genre));
    },
  },
});
