<template>
  <div class="header">
    <h1>TV Show Dashboard</h1>
    <input type="text" v-model="searchQuery" @input="updateSearch" placeholder="Search shows..." />
  </div>
</template>

<script>
export default {
  computed: {
    searchQuery: {
      get() {
        return this.$store.state.searchQuery;
      },
      set(value) {
        this.$store.commit('SET_SEARCH_QUERY', value);
      },
    },
  },
  methods: {
    updateSearch() {
      this.$store.commit('SET_SEARCH_QUERY', this.searchQuery);
    },
  },
};
</script>

<style scoped>
.header {
  background-color: #333;
  color: #fff;
  padding: 1em;
  text-align: center;
}

input[type="text"] {
  padding: 0.5em;
  width: 50%;
  margin: 1em auto;
  display: block;
}
</style>
