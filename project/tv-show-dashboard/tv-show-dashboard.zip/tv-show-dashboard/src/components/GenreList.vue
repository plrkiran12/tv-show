<template>
  <div>
    <h2>{{ genre }}</h2>
    <div class="show-list">
      <ShowCard v-for="show in shows" :key="show.id" :show="show" />
    </div>
  </div>
</template>

<script>
import ShowCard from './ShowCard.vue';

export default {
  components: {
    ShowCard,
  },
  props: {
    genre: String,
  },
  computed: {
    shows() {
      return this.$store.getters.showsByGenre(this.genre);
    },
  },
};
</script>

<style scoped>
.show-list {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}
</style>
