<template>
  <div class="show-card">
    <img :src="show.image ? show.image.medium : ''" :alt="show.name" />
    <h3>{{ show.name }}</h3>
    <p>Rating: {{ show.rating.average }}</p>
    <router-link :to="{ name: 'show-detail', params: { id: show.id } }">View Details</router-link>
  </div>
</template>

<script>
export default {
  props: {
    show: Object,
  },
};
</script>

<style scoped>
.show-card {
  border: 1px solid #ccc;
  border-radius: 8px;
  padding: 1em;
  margin: 1em;
  text-align: center;
  width: 200px;
}

.show-card img {
  width: 100%;
  border-radius: 8px;
}

.show-card h3 {
  font-size: 1.2em;
  margin: 0.5em 0;
}

.show-card p {
  margin: 0.5em 0;
}

.show-card a {
  color: #007bff;
  text-decoration: none;
}

.show-card a:hover {
  text-decoration: underline;
}
</style>
