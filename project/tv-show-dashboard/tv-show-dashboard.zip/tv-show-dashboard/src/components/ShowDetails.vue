<template>
  <div v-if="show">
    <h2>{{ show.name }}</h2>
    <img :src="show.image ? show.image.original : ''" :alt="show.name" />
    <p v-html="show.summary"></p>
    <p><strong>Genres:</strong> {{ show.genres.join(', ') }}</p>
    <p><strong>Rating:</strong> {{ show.rating.average }}</p>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      show: null,
    };
  },
  async created() {
    const showId = this.$route.params.id;
    try {
      const response = await axios.get(`https://api.tvmaze.com/shows/${showId}`);
      this.show = response.data;
    } catch (error) {
      console.error('Error fetching show details:', error);
    }
  },
};
</script>
