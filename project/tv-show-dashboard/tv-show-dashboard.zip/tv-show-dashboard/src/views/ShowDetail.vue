<template>
  <ShowDetails />
</template>

<script>
import ShowDetails from '../components/ShowDetails.vue';

export default {
  components: {
    ShowDetails,
  },
};
</script>
