<template>
  <div>
    <Header />
    <GenreList genre="Drama" />
    <GenreList genre="Comedy" />
    <GenreList genre="Sports" />
  </div>
</template>

<script>
import Header from '../components/Header.vue';
import GenreList from '../components/GenreList.vue';

export default {
  components: {
    Header,
    GenreList,
  },
  created() {
    this.$store.dispatch('fetchShows');
  },
};
</script>
